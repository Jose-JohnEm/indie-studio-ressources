/*
** EPITECH PROJECT, 2021
** B-YEP-400-LYN-4-1-indiestudio-lucas.guichard
** File description:
** Text
*/

#include "Text.hpp"

Raylib::Text::Text()
{
}

Raylib::Text::~Text()
{
}
