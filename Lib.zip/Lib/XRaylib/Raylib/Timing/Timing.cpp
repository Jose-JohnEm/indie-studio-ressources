/*
** EPITECH PROJECT, 2021
** B-YEP-400-LYN-4-1-indiestudio-lucas.guichard
** File description:
** Timing
*/

#include "Timing.hpp"

Raylib::Timing::Timing()
{
}

Raylib::Timing::~Timing()
{
}
