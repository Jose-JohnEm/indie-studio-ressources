/*
** EPITECH PROJECT, 2021
** B-YEP-400-LYN-4-1-indiestudio-lucas.guichard
** File description:
** Gamepad
*/

#include "Gamepad.hpp"

Raylib::Gamepad::Gamepad()
{
}

Raylib::Gamepad::~Gamepad()
{
}