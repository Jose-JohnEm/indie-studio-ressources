/*
** EPITECH PROJECT, 2021
** B-YEP-400-LYN-4-1-indiestudio-lucas.guichard
** File description:
** Mouse
*/

#include "Mouse.hpp"

Raylib::Mouse::Mouse()
{
}

Raylib::Mouse::~Mouse()
{
}